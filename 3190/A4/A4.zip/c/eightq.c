#include <stdio.h>

int a[8];
int b[16];
int c[14];
int x[8];
FILE *fp;


void try(int i);
void print();

int main()
{
    int i;
	fp = fopen("QueenC.txt", "w");
	for(i=1;i<9;i++)
	{
		a[i] = 1;
	}
	for(i=2;i<17;i++)
	{
		b[i] =1;
	}
	for(i=1;i<16;i++)
	{
		c[i]=1;
	}
	try(1);

    return 0;
}

void try (i)
{
	int j;
	
	for (j=1;j<9;j++)
	{
		if(a[j] == 1 && b[i+j] == 1 && c[i-j+8] == 1)
		{
			x[i] = j;
			a[j] = 0;
			b[i+j]=0;
			c[i-j+8]=0;
			if(i<8)
			{
				try(i+1);
			}
			else
			{
				print();
			}
			
			a[j] = 1;
			b[i+j]=1;
			c[i-j+8]=1;
		}
	}
}

void print()
{
	int i;
	int g;
	int static s;
	
	s=s+1;
	
	fprintf(fp,"\n");
	fprintf(fp,"Solution number: %d",s);
	fprintf(fp,"\n");
	for (i=1;i<9;i++)
	{
		for(g=1;g<9;g++)
		{
			if(x[i]==g)
			{
				fprintf(fp,"Q");
			}
			else
			{
				fprintf(fp,".");
			}
		}
		fprintf(fp,"\n");
	}
}